const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = 3000;
const JWT_SECRET = 'secretkey'; // WARNING: Should be loaded from a secure environment variable in production!

// --- Middleware ---
app.use(cors({
    origin: '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json()); // Parse JSON request bodies

// --- Database Setup ---
const dbPath = path.join(__dirname, 'database', 'evaluation.db');
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('Error opening database: ' + err.message);
    } else {
        console.log('Connected to the SQLite database.');
    }
});

// --- Utility Functions ---

// Middleware to verify JWT token
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (token == null) return res.sendStatus(401); // Unauthorized

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) return res.sendStatus(403); // Forbidden
        req.user = user;
        next();
    });
};

// Middleware to check if user is an admin
const isAdmin = (req, res, next) => {
    if (req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Access denied. Admin required.' });
    }
    next();
};

// Initialize database tables and add a default admin
const initDb = () => {
    db.serialize(() => {
        // Create users table if it doesn't exist
        db.run(`
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                email TEXT UNIQUE,
                role TEXT NOT NULL DEFAULT 'employee',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`);

        // Create feedbacks table if it doesn't exist
        db.run(`
            CREATE TABLE IF NOT EXISTS feedbacks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                employee_id INTEGER NOT NULL,
                rating INTEGER NOT NULL,
                comment TEXT,
                client_email TEXT,
                date DATETIME NOT NULL,
                admin_response TEXT,
                FOREIGN KEY (employee_id) REFERENCES users (id)
            )`);

        // Create jobs table if it doesn't exist
        db.run(`
            CREATE TABLE IF NOT EXISTS jobs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL UNIQUE,
                description TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`);

        // Add a default admin user if none exists
        db.get('SELECT id FROM users WHERE role = "admin"', async (err, row) => {
            if (err) {
                console.error('Error checking for admin:', err.message);
                return;
            }
            if (!row) {
                console.log('No admin found. Creating default admin: admin/password');
                const defaultAdminUsername = 'admin';
                const defaultAdminPassword = 'password';
                const hashedPassword = await bcrypt.hash(defaultAdminPassword, 10);
                
                db.run(
                    'INSERT INTO users (username, password, email, role) VALUES (?, ?, ?, ?)',
                    [defaultAdminUsername, hashedPassword, 'admin@example.com', 'admin'],
                    function(err) {
                        if (err) {
                            console.error('Error creating default admin:', err.message);
                        } else {
                            console.log('Default admin created successfully.');
                        }
                    }
                );
            }
        });
    });
};

// Call initialization
initDb();

// --- API Endpoints ---

// Signup endpoint (no authentication required)
app.post('/api/auth/signup', async (req, res) => {
    try {
        const { username, password, email } = req.body;
        
        if (!username || !password) {
            return res.status(400).json({ message: 'Username and password are required' });
        }

        // Check if employee already exists
        db.get('SELECT id FROM users WHERE username = ?', [username], async (err, row) => {
            if (err) {
                return res.status(500).json({ message: 'Database error' });
            }
            
            if (row) {
                return res.status(400).json({ message: 'Username already exists' });
            }

            // Hash password
            const hashedPassword = await bcrypt.hash(password, 10);
            
            // Insert new employee
            db.run(
                'INSERT INTO users (username, password, email, role) VALUES (?, ?, ?, ?)',
                [username, hashedPassword, email || null, 'employee'],
                function(err) {
                    if (err) {
                        return res.status(500).json({ message: 'Error creating employee' });
                    }
                    res.status(201).json({ 
                        message: 'User created successfully',
                        userId: this.lastID 
                    });
                }
            );
        });
    } catch (error) {
        console.error('Signup error:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// Get all users (No auth required)
app.get('/api/users', (req, res) => {
    db.all('SELECT id, username, email, role, created_at FROM users', [], (err, rows) => {
        if (err) {
            console.error('Error fetching users:', err);
            return res.status(500).json({ message: 'Error fetching users' });
        }
        res.json(rows);
    });
});

// Get all admins (No auth required)
app.get('/api/admins', (req, res) => {
    db.all('SELECT id, username, email, created_at FROM users WHERE role = ?', ['admin'], (err, rows) => {
        if (err) {
            console.error('Error fetching admins:', err);
            return res.status(500).json({ message: 'Error fetching admins' });
        }
        res.json(rows);
    });
});

// Add admin endpoint (no authentication required for testing)
app.post('/api/admin/create', async (req, res) => {
    try {
        const { username, password, email } = req.body;
        
        if (!username || !password) {
            return res.status(400).json({ message: 'Username and password are required' });
        }

        // Check if admin already exists
        db.get('SELECT id FROM users WHERE username = ?', [username], async (err, row) => {
            if (err) {
                return res.status(500).json({ message: 'Database error' });
            }
            
            if (row) {
                return res.status(400).json({ message: 'Username already exists' });
            }

            // Hash password
            const hashedPassword = await bcrypt.hash(password, 10);
            
            // Insert new admin user
            db.run(
                'INSERT INTO users (username, password, email, role) VALUES (?, ?, ?, ?)',
                [username, hashedPassword, email || null, 'admin'],
                function(err) {
                    if (err) {
                        return res.status(500).json({ message: 'Error creating admin user' });
                    }
                    res.status(201).json({ 
                        message: 'Admin user created successfully',
                        userId: this.lastID 
                    });
                }
            );
        });
    } catch (error) {
        console.error('Admin creation error:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// 1. Authentication (Login for both Admin and Employee)
app.post('/api/auth/login', (req, res) => {
    const { identifier, password, role } = req.body; // Changed 'email' to 'identifier' for clarity

    if (!identifier || !password || !role) {
        return res.status(400).json({ message: 'Identifier (username or email), password, and role are required.' });
    }

    console.log('Login attempt:', { identifier, role });

    // Use the users table and check the role
    // Check for match on username OR email
    const sql = 'SELECT * FROM users WHERE (email = ? OR username = ?) AND role = ?';
    
    db.get(sql, [identifier, identifier, role], (err, user) => {
        if (err) {
            console.error('Database error during login:', err);
            return res.status(500).json({ message: 'Database error during login' });
        }
        
        console.log('User found:', user ? 'Yes' : 'No');
        
        if (!user) {
            return res.status(401).json({ message: 'Invalid credentials or role.' });
        }

        console.log('Comparing password for user:', user.username);
        
        // Compare password
        if (bcrypt.compareSync(password, user.password)) {
            console.log('Password match successful');
            const payload = { 
                id: user.id, 
                role: user.role, 
                email: user.email,
                username: user.username
            };
            const token = jwt.sign(payload, JWT_SECRET, { expiresIn: '1h' });
            console.log("Role: ", user.role);
            console.log("Username: ", user.username);
            res.json({ 
                token, 
                role: user.role, 
                username: user.username // Use username consistently
            });
        } else {
            console.log('Password mismatch');
            res.status(401).json({ message: 'Invalid credentials.' });
        }
    });
});

// 2. Client Submits Feedback (Public Endpoint)
app.post('/api/feedback', (req, res) => {
    const { employeeEmail, rating, comment, clientEmail } = req.body;

    if (!employeeEmail || !rating) {
        return res.status(400).json({ message: 'Employee email and rating are required.' });
    }

    // Find employee ID by email
    db.get('SELECT id FROM users WHERE email = ? AND role = "employee"', [employeeEmail], (err, employee) => {
        if (err) {
            return res.status(500).json({ message: err.message });
        }
        if (!employee) {
            return res.status(404).json({ message: 'Employee not found or is not an employee role.' });
        }

        const employee_id = employee.id;
        const date = new Date().toISOString();

        const sql = `INSERT INTO feedbacks (employee_id, rating, comment, client_email, date) VALUES (?, ?, ?, ?, ?)`;
        db.run(sql, [employee_id, rating, comment, clientEmail, date], function(err) {
            if (err) {
                return res.status(500).json({ message: err.message });
            }
            res.status(201).json({ message: 'Feedback submitted successfully.', feedbackId: this.lastID });
        });
    });
});

// 3. Employee Views Their Feedbacks (Protected Endpoint)
app.get('/api/employee/feedbacks', authenticateToken, (req, res) => {
    if (req.user.role !== 'employee') {
        return res.status(403).json({ message: 'Access denied. Employee required.' });
    }

    const employee_id = req.user.id;
    const sql = `
        SELECT 
            f.id, f.rating, f.comment, f.client_email, f.date, f.admin_response, e.username as employee_username
        FROM feedbacks f
        JOIN users e ON f.employee_id = e.id
        WHERE f.employee_id = ?
        ORDER BY f.date DESC
    `;

    db.all(sql, [employee_id], (err, rows) => {
        if (err) {
            console.error('Error fetching employee feedbacks:', err);
            return res.status(500).json({ message: err.message });
        }
        res.json(rows);
    });
});

// 4. Admin Views All Feedbacks (Protected Endpoint)
app.get('/api/admin/feedbacks', authenticateToken, isAdmin, (req, res) => {
    const sql = `
        SELECT 
            f.id, f.rating, f.comment, f.client_email, f.date, f.admin_response, 
            e.username as employee_username, e.email as employee_email
        FROM feedbacks f
        JOIN users e ON f.employee_id = e.id
        ORDER BY f.date DESC
    `;

    db.all(sql, [], (err, rows) => {
        if (err) {
            console.error('Error fetching admin feedbacks:', err);
            return res.status(500).json({ message: err.message });
        }
        res.json(rows);
    });
});

// 5. Admin Responds to Feedback (Protected Endpoint)
app.post('/api/admin/feedback/:id/respond', authenticateToken, isAdmin, (req, res) => {
    const feedbackId = req.params.id;
    const { response } = req.body;

    if (!response) {
        return res.status(400).json({ message: 'Response text is required.' });
    }

    const sql = `UPDATE feedbacks SET admin_response = ? WHERE id = ?`;
    db.run(sql, [response, feedbackId], function(err) {
        if (err) {
            return res.status(500).json({ message: err.message });
        }
        if (this.changes === 0) {
            return res.status(404).json({ message: 'Feedback not found.' });
        }
        res.json({ message: 'Response added successfully.' });
    });
});

// 6. Admin Views All Employees (Protected Endpoint)
app.get('/api/admin/employees', authenticateToken, isAdmin, (req, res) => {
    // Select username instead of non-existent 'name'
    const sql = `SELECT id, username, email FROM users WHERE role = 'employee' ORDER BY username ASC`;
    db.all(sql, [], (err, rows) => {
        if (err) {
            return res.status(500).json({ message: err.message });
        }
        res.json(rows);
    });
});

// 8. Admin Views All Jobs (Protected Endpoint)
app.get('/api/admin/jobs', authenticateToken, isAdmin, (req, res) => {
    const sql = `SELECT id, title, description FROM jobs ORDER BY title ASC`;
    db.all(sql, [], (err, rows) => {
        if (err) {
            return res.status(500).json({ message: err.message });
        }
        res.json(rows);
    });
});

// 9. Admin Creates a New Job (Protected Endpoint)
app.post('/api/admin/jobs', authenticateToken, isAdmin, (req, res) => {
    const { title, description } = req.body;
    if (!title) {
        return res.status(400).json({ message: 'Job title is required.' });
    }

    const sql = `INSERT INTO jobs (title, description) VALUES (?, ?)`;
    db.run(sql, [title, description], function(err) {
        if (err) {
            // Check for unique constraint error
            if (err.message.includes('UNIQUE constraint failed')) {
                return res.status(400).json({ message: 'A job with this title already exists.' });
            }
            return res.status(500).json({ message: err.message });
        }
        res.status(201).json({ message: 'Job created successfully.', jobId: this.lastID });
    });
});

// 10. Admin Updates a Job (Protected Endpoint)
app.put('/api/admin/jobs/:id', authenticateToken, isAdmin, (req, res) => {
    const jobId = req.params.id;
    const { title, description } = req.body;
    if (!title) {
        return res.status(400).json({ message: 'Job title is required.' });
    }

    const sql = `UPDATE jobs SET title = ?, description = ? WHERE id = ?`;
    db.run(sql, [title, description, jobId], function(err) {
        if (err) {
            // Check for unique constraint error
            if (err.message.includes('UNIQUE constraint failed')) {
                return res.status(400).json({ message: 'A job with this title already exists.' });
            }
            return res.status(500).json({ message: err.message });
        }
        if (this.changes === 0) {
            return res.status(404).json({ message: 'Job not found.' });
        }
        res.json({ message: 'Job updated successfully.' });
    });
});

// 11. Admin Deletes a Job (Protected Endpoint)
app.delete('/api/admin/jobs/:id', authenticateToken, isAdmin, (req, res) => {
    const jobId = req.params.id;
    const sql = `DELETE FROM jobs WHERE id = ?`;
    db.run(sql, [jobId], function(err) {
        if (err) {
            return res.status(500).json({ message: err.message });
        }
        if (this.changes === 0) {
            return res.status(404).json({ message: 'Job not found.' });
        }
        res.json({ message: 'Job deleted successfully.' });
    });
});

// 7. Admin gets general reports (Protected Endpoint)
app.get('/api/admin/reports', authenticateToken, isAdmin, (req, res) => {
    const totalEmployeesSql = 'SELECT COUNT(id) as totalEmployees FROM users WHERE role = "employee"';
    const totalFeedbacksSql = 'SELECT COUNT(id) as totalFeedbacks FROM feedbacks';
    const avgRatingSql = 'SELECT AVG(rating) as averageRating FROM feedbacks';
    const topEmployeesSql = `
        SELECT 
            e.username, 
            COUNT(f.id) as feedbackCount, 
            AVG(f.rating) as averageRating
        FROM users e
        JOIN feedbacks f ON e.id = f.employee_id
        WHERE e.role = 'employee'
        GROUP BY e.id, e.username
        ORDER BY averageRating DESC, feedbackCount DESC
        LIMIT 5
    `;

    const reports = {};

    db.get(totalEmployeesSql, (err, row) => {
        if (err) return res.status(500).json({ message: err.message });
        reports.totalEmployees = row.totalEmployees;

        db.get(totalFeedbacksSql, (err, row) => {
            if (err) return res.status(500).json({ message: err.message });
            reports.totalFeedbacks = row.totalFeedbacks;

            db.get(avgRatingSql, (err, row) => {
                if (err) return res.status(500).json({ message: err.message });
                reports.averageRating = parseFloat(row.averageRating || 0).toFixed(2); // Handle null/0 case

                db.all(topEmployeesSql, (err, rows) => {
                    if (err) return res.status(500).json({ message: err.message });
                    reports.topEmployees = rows.map(row => ({
                        username: row.username,
                        feedbackCount: row.feedbackCount,
                        averageRating: parseFloat(row.averageRating).toFixed(2)
                    }));
                    res.json(reports);
                });
            });
        });
    });
});

// Drop database (DANGEROUS - Use with caution!)
app.post('/api/db/drop', (req, res) => {
    try {
        // Drop all tables
        db.serialize(() => {
            // Drop users table
            db.run('DROP TABLE IF EXISTS users', (err) => {
                if (err) {
                    console.error('Error dropping users table:', err);
                    return res.status(500).json({ message: 'Error dropping database tables' });
                }
                console.log('Dropped users table');
            });

            // Drop feedbacks table
            db.run('DROP TABLE IF EXISTS feedbacks', (err) => {
                if (err) {
                    console.error('Error dropping feedbacks table:', err);
                    return res.status(500).json({ message: 'Error dropping database tables' });
                }
                console.log('Dropped feedbacks table');
            });
        });

        // Re-initialize the database
        initDb();
        
        res.json({ message: 'Database dropped and reinitialized successfully' });
    } catch (error) {
        console.error('Error dropping database:', error);
        res.status(500).json({ message: 'Internal server error while dropping database' });
    }
});

// --- Serve Frontend Static Files (for local development)
// This will serve the HTML/CSS/JS files from the frontend directory
const frontendPath = path.join(__dirname, '..', 'frontend');
app.use(express.static(frontendPath));

// Catch-all route for SPA - only for non-API routes
app.get(/^(?!\/api\/).*/, (req, res) => {
    res.sendFile(path.join(frontendPath, 'home.html'));
});

// --- Start Server ---
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
