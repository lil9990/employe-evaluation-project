const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const path = require('path');

// Path to the database file
const dbPath = path.join(__dirname, 'database', 'evaluation.db');
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('Error opening database ' + err.message);
    } else {
        console.log('Connected to the SQLite database.');
    }
});

// Hash a default password for initial users
const defaultPassword = 'password123';
const adminHashedPassword = bcrypt.hashSync(defaultPassword, 10);
const employeeHashedPassword = bcrypt.hashSync(defaultPassword, 10);

db.serialize(() => {
    // Drop tables if they exist (for clean setup)
    db.run("DROP TABLE IF EXISTS admins");
    db.run("DROP TABLE IF EXISTS employees");
    db.run("DROP TABLE IF EXISTS feedbacks");

    // 1. Admins Table
    db.run(`CREATE TABLE admins (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL
    )`);

    // Insert a default admin
    db.run(`INSERT INTO admins (username, password) VALUES (?, ?)`, 
        ['admin', adminHashedPassword], 
        function(err) {
            if (err) {
                console.log('Error inserting default admin: ' + err.message);
            } else {
                console.log('Default admin created with username: admin and password: ' + defaultPassword);
            }
        }
    );

    // 2. Employees Table
    db.run(`CREATE TABLE employees (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL
    )`);

    // Insert default employees
    db.run(`INSERT INTO employees (name, email, password) VALUES (?, ?, ?)`, 
        ['أحمد محمد', 'ahmed@company.com', employeeHashedPassword]
    );
    db.run(`INSERT INTO employees (name, email, password) VALUES (?, ?, ?)`, 
        ['Fatima Ali', 'fatima@company.com', employeeHashedPassword],
        function(err) {
            if (!err) {
                console.log('Default employees created with password: ' + defaultPassword);
            }
        }
    );

    // 3. Feedbacks Table
    db.run(`CREATE TABLE feedbacks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        employee_id INTEGER NOT NULL,
        rating INTEGER NOT NULL,
        comment TEXT,
        client_email TEXT,
        date TEXT NOT NULL,
        admin_response TEXT,
        FOREIGN KEY (employee_id) REFERENCES employees(id)
    )`);

    // Insert some initial feedback
    db.run(`INSERT INTO feedbacks (employee_id, rating, comment, client_email, date, admin_response) VALUES (?, ?, ?, ?, ?, ?)`,
        [1, 5, 'خدمة ممتازة وسرعة في الإنجاز.', 'client1@mail.com', new Date().toISOString(), 'شكراً لتقييمك، نسعى دائماً لرضاكم.']
    );
    db.run(`INSERT INTO feedbacks (employee_id, rating, comment, client_email, date) VALUES (?, ?, ?, ?, ?)`,
        [2, 4, 'Good service, but a bit slow response time.', 'client2@mail.com', new Date().toISOString()]
    );

    db.close((err) => {
        if (err) {
            console.error(err.message);
        }
        console.log('Database setup complete and connection closed.');
    });
});
