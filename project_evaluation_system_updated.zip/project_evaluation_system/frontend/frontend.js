// Base URL for the API
const API_BASE_URL = 'http://localhost:3000/api';

// --- Localization Data (Arabic and English) ---
const translations = {
    ar: {
        // General
        'app_title': 'نظام تقييم الموظفين',
        'login_title': 'تسجيل الدخول',
        'employee_login': 'تسجيل دخول الموظف',
        'submit_feedback': 'إرسال تقييم جديد',
        'admin_login': 'تسجيل دخول المدير',
        'email_placeholder': 'البريد الإلكتروني (للموظف) أو اسم المستخدم (للمدير)',
        'password_placeholder': 'كلمة المرور',
        'login_button': 'دخول',
        'logout_button': 'خروج',
        'welcome_message': 'أهلاً بك، ',
        'feedback_list_title': 'تقييماتي',
        'feedback_rating': 'التقييم',
        'feedback_comment': 'تعليق العميل',
        'feedback_date': 'التاريخ',
        'admin_response': 'رد الإدارة',
        'no_feedbacks': 'لا توجد تقييمات لعرضها.',
        'submit_feedback_title': 'إرسال تقييم جديد',
        'employee_email': 'بريد الموظف الإلكتروني',
        'client_email': 'بريدك الإلكتروني (اختياري)',
        'rating_label': 'التقييم (1-5)',
        'comment_label': 'التعليق',
        'submit_button': 'إرسال التقييم',
        'feedback_success': 'تم إرسال التقييم بنجاح!',
        'feedback_error': 'حدث خطأ أثناء إرسال التقييم.',
        'admin_dashboard_title': 'لوحة تحكم المدير',
        'all_feedbacks_title': 'جميع التقييمات',
        'employee_name': 'اسم الموظف',
        'employee_email_admin': 'بريد الموظف',
        'respond_button': 'الرد',
        'response_placeholder': 'اكتب رد الإدارة هنا...',
        'send_response': 'إرسال الرد',
        'reports_title': 'التقارير العامة',
        'total_employees': 'إجمالي الموظفين',
        'total_feedbacks': 'إجمالي التقييمات',
        'average_rating': 'متوسط التقييم',
        'top_employees': 'أفضل 5 موظفين',
        'feedback_count': 'عدد التقييمات',
        'average_rating_short': 'متوسط',
        'view_reports': 'عرض التقارير',
        'view_feedbacks': 'عرض التقييمات',
        'manage_employees': 'إدارة الموظفين',
        'manage_jobs': 'إدارة الوظائف',
        'jobs_list_title': 'قائمة الوظائف',
        'job_title': 'عنوان الوظيفة',
        'job_description': 'وصف الوظيفة',
        'add_job_button': 'إضافة وظيفة جديدة',
        'edit_job_button': 'تعديل',
        'delete_job_button': 'حذف',
        'job_added_success': 'تم إضافة الوظيفة بنجاح.',
        'job_updated_success': 'تم تحديث الوظيفة بنجاح.',
        'job_deleted_success': 'تم حذف الوظيفة بنجاح.',
        'job_title_required': 'عنوان الوظيفة مطلوب.',
        'confirm_delete_job': 'هل أنت متأكد من حذف هذه الوظيفة؟',
        'employees_list_title': 'قائمة الموظفين',
        'employee_id': 'الرقم التعريفي',
        'employee_actions': 'الإجراءات',
        'admin_response_success': 'تم إرسال الرد بنجاح.',
        'admin_response_error': 'حدث خطأ أثناء إرسال الرد.',
        'login_error': 'فشل تسجيل الدخول. تحقق من البيانات.',
        'language_switch': 'English',
        'dir': 'rtl'
    },
    en: {
        // General
        'app_title': 'Employee Evaluation System',
        'login_title': 'Login',
        'employee_login': 'Employee Login',
        'submit_feedback': 'Submit Feedback',
        'admin_login': 'Admin Login',
        'email_placeholder': 'Email (Employee) or Username (Admin)',
        'password_placeholder': 'Password',
        'login_button': 'Login',
        'logout_button': 'Logout',
        'welcome_message': 'Welcome, ',
        'feedback_list_title': 'My Feedbacks',
        'feedback_rating': 'Rating',
        'feedback_comment': 'Client Comment',
        'feedback_date': 'Date',
        'admin_response': 'Admin Response',
        'no_feedbacks': 'No feedbacks to display.',
        'submit_feedback_title': 'Submit New Feedback',
        'employee_email': 'Employee Email',
        'client_email': 'Your Email (Optional)',
        'rating_label': 'Rating (1-5)',
        'comment_label': 'Comment',
        'submit_button': 'Submit Feedback',
        'feedback_success': 'Feedback submitted successfully!',
        'feedback_error': 'An error occurred while submitting feedback.',
        'admin_dashboard_title': 'Admin Dashboard',
        'all_feedbacks_title': 'All Feedbacks',
        'employee_name': 'Employee Name',
        'employee_email_admin': 'Employee Email',
        'respond_button': 'Respond',
        'response_placeholder': 'Write admin response here...',
        'send_response': 'Send Response',
        'reports_title': 'General Reports',
        'total_employees': 'Total Employees',
        'total_feedbacks': 'Total Feedbacks',
        'average_rating': 'Average Rating',
        'top_employees': 'Top 5 Employees',
        'feedback_count': 'Feedback Count',
        'average_rating_short': 'Avg. Rating',
        'view_reports': 'View Reports',
        'view_feedbacks': 'View Feedbacks',
        'manage_employees': 'Manage Employees',
        'manage_jobs': 'Manage Jobs',
        'jobs_list_title': 'Jobs List',
        'job_title': 'Job Title',
        'job_description': 'Job Description',
        'add_job_button': 'Add New Job',
        'edit_job_button': 'Edit',
        'delete_job_button': 'Delete',
        'job_added_success': 'Job added successfully.',
        'job_updated_success': 'Job updated successfully.',
        'job_deleted_success': 'Job deleted successfully.',
        'job_title_required': 'Job title is required.',
        'confirm_delete_job': 'Are you sure you want to delete this job?',
        'employees_list_title': 'Employees List',
        'employee_id': 'ID',
        'employee_actions': 'Actions',
        'admin_response_success': 'Response sent successfully.',
        'admin_response_error': 'An error occurred while sending the response.',
        'login_error': 'Login failed. Check your credentials.',
        'language_switch': 'العربية',
        'dir': 'ltr'
    }
};

let currentLang = localStorage.getItem('lang') || 'ar';

// --- Localization Function ---
function setLanguage(lang) {
    currentLang = lang;
    localStorage.setItem('lang', lang);
    const t = translations[lang];

    // Set document direction
    document.documentElement.dir = t.dir;
    document.documentElement.lang = lang;

    // Update all elements with data-translate-key
    document.querySelectorAll('[data-translate-key]').forEach(el => {
        const key = el.getAttribute('data-translate-key');
        if (t[key]) {
            if (el.tagName === 'INPUT' && el.type === 'submit') {
                el.value = t[key];
            } else if (el.tagName === 'INPUT' && el.type === 'text' || el.tagName === 'INPUT' && el.type === 'password') {
                el.placeholder = t[key];
            } else {
                el.textContent = t[key];
            }
        }
    });

    // Update language switch button
    const langSwitch = document.getElementById('language-switch');
    if (langSwitch) {
        langSwitch.textContent = t.language_switch;
    }
}

// --- Language Switch Handler ---
function toggleLanguage() {
    const newLang = currentLang === 'ar' ? 'en' : 'ar';
    setLanguage(newLang);
}

// --- Authentication Functions ---
function saveAuth(token, role, username) { // Changed 'name' to 'username'
    // Normalize role to lowercase for consistent comparison
    const normalizedRole = role ? role.toLowerCase() : 'employee';
    const authData = { token, role: normalizedRole, username }; // Changed 'name' to 'username'
    localStorage.setItem('auth', JSON.stringify(authData));
    // Save individual items for easier access (legacy support)
    localStorage.setItem('token', token);
    localStorage.setItem('role', normalizedRole);
    localStorage.setItem('username', username); // Changed 'name' to 'username'
    // Update UI immediately after saving auth data
    updateAuthUI();
}

function getAuth() {
    // Retrieve from individual items for backward compatibility
    return {
        token: localStorage.getItem('token'),
        role: localStorage.getItem('role'),
        username: localStorage.getItem('username') // Changed 'name' to 'username'
    };
}

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    localStorage.removeItem('username'); // Changed 'name' to 'username'
    window.location.href = 'login.html'; // Redirect to login page
}

// --- API Calls ---

// Handle Login Form Submission
async function handleLogin(event) {
    event.preventDefault();
    const form = event.target;
    // Use 'email' input field as the generic 'identifier' (email or username)
    const identifier = form.email.value; 
    const password = form.password.value;
    const role = form.role.value; // 'admin' or 'employee'

    try {
        const response = await fetch(`${API_BASE_URL}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            // Send 'identifier' instead of 'email'
            body: JSON.stringify({ identifier, password, role }) 
        });

        const data = await response.json();

        if (response.ok) {
            // Save username, not name
            saveAuth(data.token, data.role, data.username); 
            // Update UI immediately
            updateAuthUI();
            
            // Redirect based on role (case-insensitive check)
            if (data.role.toLowerCase() === 'admin') {
                window.location.href = 'admen.html';
            } else {
                window.location.href = 'dashboard.html';
            }
        } else {
            alert(translations[currentLang].login_error + ': ' + (data.message || 'Invalid credentials'));
        }
    } catch (error) {
        console.error('Login error:', error);
        alert(translations[currentLang].login_error + ': ' + error.message);
    }
}

// Handle Feedback Submission Form
async function handleSubmitFeedback(event) {
    event.preventDefault();
    const form = event.target;
    const employeeEmail = form.employeeEmail.value;
    const clientEmail = form.clientEmail.value;
    const rating = form.rating.value;
    const comment = form.comment.value;

    try {
        const response = await fetch(`${API_BASE_URL}/feedback`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ employeeEmail, rating: parseInt(rating), comment, clientEmail })
        });

        const data = await response.json();

        if (response.ok) {
            alert(translations[currentLang].feedback_success);
            form.reset();
        } else {
            alert(translations[currentLang].feedback_error + ': ' + (data.message || 'Unknown error'));
        }
    } catch (error) {
        console.error('Feedback submission error:', error);
        alert(translations[currentLang].feedback_error);
    }
}

// Fetch and Display Employee Feedbacks
async function fetchEmployeeFeedbacks() {
    const auth = getAuth();
    if (!auth.token || auth.role !== 'employee') {
        logout();
        return;
    }

    // Use auth.username instead of auth.name
    document.getElementById('welcome-message').textContent = translations[currentLang].welcome_message + auth.username;

    try {
        const response = await fetch(`${API_BASE_URL}/employee/feedbacks`, {
            headers: { 'Authorization': `Bearer ${auth.token}` }
        });

        const feedbacks = await response.json();
        const container = document.getElementById('feedbacks-container');
        container.innerHTML = ''; // Clear previous content

        if (feedbacks.length === 0) {
            container.innerHTML = `<p data-translate-key="no_feedbacks">${translations[currentLang].no_feedbacks}</p>`;
            return;
        }

        const table = document.createElement('table');
        table.innerHTML = `
            <thead>
                <tr>
                    <th data-translate-key="feedback_rating">${translations[currentLang].feedback_rating}</th>
                    <th data-translate-key="feedback_comment">${translations[currentLang].feedback_comment}</th>
                    <th data-translate-key="feedback_date">${translations[currentLang].feedback_date}</th>
                    <th data-translate-key="admin_response">${translations[currentLang].admin_response}</th>
                </tr>
            </thead>
            <tbody></tbody>
        `;
        const tbody = table.querySelector('tbody');

        feedbacks.forEach(f => {
            const row = tbody.insertRow();
            row.insertCell().textContent = f.rating;
            row.insertCell().textContent = f.comment || '-';
            row.insertCell().textContent = new Date(f.date).toLocaleDateString(currentLang);
            row.insertCell().textContent = f.admin_response || '-';
        });

        container.appendChild(table);
    } catch (error) {
        console.error('Error fetching employee feedbacks:', error);
        alert('Error loading feedbacks.');
    }
}

// Fetch and Display Admin Feedbacks
async function fetchAdminFeedbacks() {
    const auth = getAuth();
    if (!auth.token || auth.role !== 'admin') {
        logout();
        return;
    }

    try {
        const response = await fetch(`${API_BASE_URL}/admin/feedbacks`, {
            headers: { 'Authorization': `Bearer ${auth.token}` }
        });

        const feedbacks = await response.json();
        const container = document.getElementById('admin-feedbacks-container');
        container.innerHTML = '';

        if (feedbacks.length === 0) {
            container.innerHTML = `<p data-translate-key="no_feedbacks">${translations[currentLang].no_feedbacks}</p>`;
            return;
        }

        const table = document.createElement('table');
        table.innerHTML = `
            <thead>
                <tr>
                    <th data-translate-key="employee_name">${translations[currentLang].employee_name}</th>
                    <th data-translate-key="feedback_rating">${translations[currentLang].feedback_rating}</th>
                    <th data-translate-key="feedback_comment">${translations[currentLang].feedback_comment}</th>
                    <th data-translate-key="admin_response">${translations[currentLang].admin_response}</th>
                    <th data-translate-key="employee_actions">${translations[currentLang].employee_actions}</th>
                </tr>
            </thead>
            <tbody></tbody>
        `;
        const tbody = table.querySelector('tbody');

        feedbacks.forEach(f => {
            const row = tbody.insertRow();
            // Use employee_username from the backend response
            row.insertCell().textContent = f.employee_username; 
            row.insertCell().textContent = f.rating;
            row.insertCell().textContent = f.comment || '-';
            
            const responseCell = row.insertCell();
            responseCell.textContent = f.admin_response || '-';

            const actionCell = row.insertCell();
            const respondButton = document.createElement('button');
            respondButton.textContent = translations[currentLang].respond_button;
            respondButton.setAttribute('data-translate-key', 'respond_button');
            respondButton.onclick = () => showResponseModal(f.id, f.admin_response);
            actionCell.appendChild(respondButton);
        });

        container.appendChild(table);
    } catch (error) {
        console.error('Error fetching admin feedbacks:', error);
        alert('Error loading admin feedbacks.');
    }
}

// Show Modal for Admin Response
function showResponseModal(feedbackId, currentResponse) {
    const modal = document.getElementById('response-modal');
    const textarea = document.getElementById('response-textarea');
    const form = document.getElementById('response-form');

    textarea.value = currentResponse || '';
    form.onsubmit = (e) => handleAdminResponse(e, feedbackId);

    modal.style.display = 'block';
}

// Handle Admin Response Submission
async function handleAdminResponse(event, feedbackId) {
    event.preventDefault();
    const responseText = document.getElementById('response-textarea').value;
    const auth = getAuth();

    try {
        const response = await fetch(`${API_BASE_URL}/admin/feedback/${feedbackId}/respond`, {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${auth.token}`
            },
            body: JSON.stringify({ response: responseText })
        });

        if (response.ok) {
            alert(translations[currentLang].admin_response_success);
            document.getElementById('response-modal').style.display = 'none';
            fetchAdminFeedbacks(); // Refresh the list
        } else {
            const data = await response.json();
            alert(translations[currentLang].admin_response_error + ': ' + (data.message || 'Unknown error'));
        }
    } catch (error) {
        console.error('Error submitting admin response:', error);
        alert(translations[currentLang].admin_response_error);
    }
}

// Fetch and Display Admin Reports
async function fetchAdminReports() {
    const auth = getAuth();
    if (!auth.token || auth.role !== 'admin') {
        logout();
        return;
    }

    try {
        const response = await fetch(`${API_BASE_URL}/admin/reports`, {
            headers: { 'Authorization': `Bearer ${auth.token}` }
        });

        const reports = await response.json();
        const container = document.getElementById('reports-container');
        container.innerHTML = '';

        // General Stats
        container.innerHTML += `
            <div class="stats-card">
                <h3 data-translate-key="total_employees">${translations[currentLang].total_employees}</h3>
                <p>${reports.totalEmployees}</p>
            </div>
            <div class="stats-card">
                <h3 data-translate-key="total_feedbacks">${translations[currentLang].total_feedbacks}</h3>
                <p>${reports.totalFeedbacks}</p>
            </div>
            <div class="stats-card">
                <h3 data-translate-key="average_rating">${translations[currentLang].average_rating}</h3>
                <p>${reports.averageRating}</p>
            </div>
        `;

        // Top Employees Table
        const topEmployeesTitle = document.createElement('h2');
        topEmployeesTitle.setAttribute('data-translate-key', 'top_employees');
        topEmployeesTitle.textContent = translations[currentLang].top_employees;
        container.appendChild(topEmployeesTitle);

        const table = document.createElement('table');
        table.innerHTML = `
            <thead>
                <tr>
                    <th data-translate-key="employee_name">${translations[currentLang].employee_name}</th>
                    <th data-translate-key="feedback_count">${translations[currentLang].feedback_count}</th>
                    <th data-translate-key="average_rating_short">${translations[currentLang].average_rating_short}</th>
                </tr>
            </thead>
            <tbody></tbody>
        `;
        const tbody = table.querySelector('tbody');

        reports.topEmployees.forEach(e => {
            const row = tbody.insertRow();
            // Use e.username from the backend response
            row.insertCell().textContent = e.username; 
            row.insertCell().textContent = e.feedbackCount;
            row.insertCell().textContent = parseFloat(e.averageRating).toFixed(2);
        });

        container.appendChild(table);

    } catch (error) {
        console.error('Error fetching admin reports:', error);
        alert('Error loading admin reports.');
    }
}

// --- Job Management Functions (for admen.html) ---

// Fetch and Display All Jobs
async function fetchAllJobs() {
    const auth = getAuth();
    if (!auth.token || auth.role !== 'admin') {
        logout();
        return;
    }

    try {
        const response = await fetch(`${API_BASE_URL}/admin/jobs`, {
            headers: { 'Authorization': `Bearer ${auth.token}` }
        });

        const jobs = await response.json();
        const container = document.getElementById('jobs-container');
        container.innerHTML = '';

        if (jobs.length === 0) {
            container.innerHTML = `<p>No jobs found.</p>`;
        }

        const table = document.createElement('table');
        table.innerHTML = `
            <thead>
                <tr>
                    <th data-translate-key="employee_id">${translations[currentLang].employee_id}</th>
                    <th data-translate-key="job_title">${translations[currentLang].job_title}</th>
                    <th data-translate-key="job_description">${translations[currentLang].job_description}</th>
                    <th data-translate-key="employee_actions">${translations[currentLang].employee_actions}</th>
                </tr>
            </thead>
            <tbody></tbody>
        `;
        const tbody = table.querySelector('tbody');

        jobs.forEach(job => {
            const row = tbody.insertRow();
            row.insertCell().textContent = job.id;
            row.insertCell().textContent = job.title;
            row.insertCell().textContent = job.description || '-';
            
            const actionCell = row.insertCell();
            const editBtn = document.createElement('button');
            editBtn.textContent = translations[currentLang].edit_job_button;
            editBtn.onclick = () => showJobModal(job.id, job.title, job.description);
            actionCell.appendChild(editBtn);

            const deleteBtn = document.createElement('button');
            deleteBtn.textContent = translations[currentLang].delete_job_button;
            deleteBtn.classList.add('logout-btn'); // Reusing the red button style
            deleteBtn.onclick = () => deleteJob(job.id, job.title);
            actionCell.appendChild(deleteBtn);
        });

        container.appendChild(table);
        
        // Add "Add New Job" button
        const addBtn = document.createElement('button');
        addBtn.textContent = translations[currentLang].add_job_button;
        addBtn.style.marginTop = '20px';
        addBtn.onclick = () => showJobModal(null, '', '');
        container.prepend(addBtn);

    } catch (error) {
        console.error('Error fetching jobs:', error);
        alert('Error loading jobs.');
    }
}

// Show Modal for Adding/Editing Job
function showJobModal(jobId, title, description) {
    const modal = document.getElementById('job-modal');
    const form = document.getElementById('job-form');
    const titleInput = document.getElementById('job-title-input');
    const descriptionInput = document.getElementById('job-description-input');
    const modalTitle = document.getElementById('job-modal-title');

    form.dataset.jobId = jobId || '';
    titleInput.value = title || '';
    descriptionInput.value = description || '';
    
    if (jobId) {
        modalTitle.textContent = translations[currentLang].edit_job_button + ': ' + title;
    } else {
        modalTitle.textContent = translations[currentLang].add_job_button;
    }

    modal.style.display = 'block';
}

// Handle Job Submission (Add or Edit)
async function handleJobSubmission(event) {
    event.preventDefault();
    const form = event.target;
    const jobId = form.dataset.jobId;
    const title = document.getElementById('job-title-input').value;
    const description = document.getElementById('job-description-input').value;
    const auth = getAuth();

    if (!title) {
        alert(translations[currentLang].job_title_required);
        return;
    }

    const method = jobId ? 'PUT' : 'POST';
    const url = jobId ? `${API_BASE_URL}/admin/jobs/${jobId}` : `${API_BASE_URL}/admin/jobs`;

    try {
        const response = await fetch(url, {
            method: method,
            headers: { 
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${auth.token}`
            },
            body: JSON.stringify({ title, description })
        });

        const data = await response.json();

        if (response.ok) {
            alert(jobId ? translations[currentLang].job_updated_success : translations[currentLang].job_added_success);
            document.getElementById('job-modal').style.display = 'none';
            fetchAllJobs(); // Refresh the list
        } else {
            alert('Error: ' + (data.message || 'Unknown error'));
        }
    } catch (error) {
        console.error('Error submitting job:', error);
        alert('Error submitting job.');
    }
}

// Handle Job Deletion
async function deleteJob(jobId, jobTitle) {
    if (!confirm(translations[currentLang].confirm_delete_job + ` (${jobTitle})`)) {
        return;
    }

    const auth = getAuth();

    try {
        const response = await fetch(`${API_BASE_URL}/admin/jobs/${jobId}`, {
            method: 'DELETE',
            headers: { 
                'Authorization': `Bearer ${auth.token}`
            }
        });

        const data = await response.json();

        if (response.ok) {
            alert(translations[currentLang].job_deleted_success);
            fetchAllJobs(); // Refresh the list
        } else {
            alert('Error: ' + (data.message || 'Unknown error'));
        }
    } catch (error) {
        console.error('Error deleting job:', error);
        alert('Error deleting job.');
    }
}

// Fetch and Display All Employees (for admen.html)
async function fetchAllEmployees() {
    const auth = getAuth();
    if (!auth.token || auth.role !== 'admin') {
        logout();
        return;
    }

    try {
        const response = await fetch(`${API_BASE_URL}/admin/employees`, {
            headers: { 'Authorization': `Bearer ${auth.token}` }
        });

        const employees = await response.json();
        const container = document.getElementById('employees-container');
        container.innerHTML = '';

        if (employees.length === 0) {
            container.innerHTML = `<p>No employees found.</p>`;
            return;
        }

        const table = document.createElement('table');
        table.innerHTML = `
            <thead>
                <tr>
                    <th data-translate-key="employee_id">${translations[currentLang].employee_id}</th>
                    <th data-translate-key="employee_name">${translations[currentLang].employee_name}</th>
                    <th data-translate-key="employee_email_admin">${translations[currentLang].employee_email_admin}</th>
                </tr>
            </thead>
            <tbody></tbody>
        `;
        const tbody = table.querySelector('tbody');

        employees.forEach(e => {
            const row = tbody.insertRow();
            row.insertCell().textContent = e.id;
            // Use e.username from the backend response
            row.insertCell().textContent = e.username; 
            row.insertCell().textContent = e.email;
        });

        container.appendChild(table);
    } catch (error) {
        console.error('Error fetching employees:', error);
        alert('Error loading employees.');
    }
}

// Function to update UI based on authentication state
function updateAuthUI() {
    const auth = getAuth();
    const welcomeElement = document.getElementById('welcome-message');
    const loginBtn = document.querySelector('.login-btn');
    const logoutBtn = document.getElementById('logout-button');
    const feedbackBox = document.querySelector('a[href="feedback.html"]');

    // Check for auth.username instead of auth.name
    if (auth.token && auth.username) { 
        // User is logged in
        if (welcomeElement) {
            // Use auth.username instead of auth.name
            welcomeElement.textContent = translations[currentLang].welcome_message + auth.username; 
        }
        if (loginBtn) loginBtn.style.display = 'none';
        if (logoutBtn) logoutBtn.style.display = 'block';
        if (feedbackBox) feedbackBox.style.display = 'block';
    } else {
        // User is not logged in
        if (welcomeElement) welcomeElement.textContent = translations[currentLang].welcome_guest || 'Welcome, Guest';
        if (loginBtn) loginBtn.style.display = 'block';
        if (logoutBtn) logoutBtn.style.display = 'none';
        if (feedbackBox) feedbackBox.style.display = 'none';
    }
}

// Update the logout function to refresh the page
function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    localStorage.removeItem('username'); // Ensure 'username' is removed
    localStorage.removeItem('name'); // Remove old 'name' key just in case
    updateAuthUI();
    window.location.href = 'home.html';
}

// --- Initialization ---
document.addEventListener('DOMContentLoaded', () => {
    setLanguage(currentLang);
    updateAuthUI();

    // Attach event listeners to forms
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }

    const feedbackForm = document.getElementById('feedback-form');
    if (feedbackForm) {
        feedbackForm.addEventListener('submit', handleSubmitFeedback);
    }

    // Attach event listener to language switch button
    const langSwitch = document.getElementById('language-switch');
    if (langSwitch) {
        langSwitch.addEventListener('click', toggleLanguage);
    }

    // Load data based on the current page
    if (document.body.classList.contains('employee-page')) {
        fetchEmployeeFeedbacks();
    } else if (document.body.classList.contains('admin-feedbacks-page')) {
        fetchAdminFeedbacks();
    } else if (document.body.classList.contains('admin-reports-page')) {
        fetchAdminReports();
    } else if (document.body.classList.contains('admin-employees-page')) {
        fetchAllEmployees();
    }

    // Close modal when clicking outside or on close button
    const modal = document.getElementById('response-modal');
    if (modal) {
        const closeBtn = document.querySelector('.close-button');
        closeBtn.onclick = () => modal.style.display = 'none';
        window.onclick = (event) => {
            if (event.target == modal) {
                modal.style.display = 'none';
            }
        };
    }
});

// Export functions for use in HTML (e.g., onclick)
window.logout = logout;
window.toggleLanguage = toggleLanguage;
window.showResponseModal = showResponseModal;
window.handleAdminResponse = handleAdminResponse;
window.fetchAdminFeedbacks = fetchAdminFeedbacks;
window.fetchAdminReports = fetchAdminReports;
window.fetchAllEmployees = fetchAllEmployees;
window.setLanguage = setLanguage;
